#include<iostream>
using namespace std;

class Node {
	public :
	int data;
	Node *next;

	Node(int data) {
		this -> data = data;
		next = NULL;
	}
};

Node* takeInput() {
	int data;
	cin >> data;
	Node *head = NULL;
	Node *tail = NULL;
	while(data != -1) {
		Node *newNode = new Node(data);
		if(head == NULL) {
			head = newNode;
			tail = newNode;
		}
		else {
			tail -> next = newNode;
			tail = tail -> next;

		}

		cin >> data;
	}
	return head;
}


int length(Node *head) {

    Node *temp = head;
  
    int count =0;
  
  while(temp -> data != -1)
  {
    temp = temp -> next;
    count++;
  }
  return count ;
}

Node* insertNode(Node *head, int i, int data) {
	Node *newNode = new Node(data);
	int count = 0;
	Node *temp = head;

	if(i == 0) {
		newNode -> next = head;
		head = newNode;
		return head;
	}

	while(temp != NULL && count < i - 1) {
		temp = temp -> next;
		count++;
	}
	if(temp != NULL) {
		Node *a = temp -> next;
		temp -> next = newNode;
		newNode -> next = a;
	}
	return head;
}

Node* deleteNode(Node *head, int i) {
   
    if(i==0)
    { Node *a = head;
      head = head ->next;
     delete a;
      return head;
    }
  
  else
  {
    Node *temp = head;
    int count =0;
    while(temp != NULL && count < i-1)
    {
      temp = temp -> next;
      count++;
    }
     Node *a = temp ->next;
    if(temp != NULL && a!= NULL)
    {
     temp -> next = a ->next;
    delete a;
    return head;
    }
    
  }
  return head;
}

Node* insertNodeRec(Node *head, int i, int data) {
    
  if(head == NULL)
  {
    if(i==0)
    {
      Node *newnode = new Node(data);
      head = newnode;
      return head;
    }
    else return head;
  }
  
  if(i == 0)
  {
    Node *newnode = new Node(data);
    newnode -> next = head ;
    head = newnode;
    return head;
  }
  Node *h = insertNodeRec(head -> next, i-1, data);
  head -> next = h;
  return head;
}
Node* deleteNodeRec(Node *head, int i) {
  if(head == NULL)
  {
    return head;
  }
  
  if(i==0)
  { 
    Node *a = head;
    head = head -> next;
    delete a;
  }
  head -> next = deleteNodeRec(head -> next, i-1);
  return head;
  
    
}




void print(Node *head) {
	Node *temp = head;
	
		while(temp != NULL) {
		cout << temp -> data << " ";
		temp = temp -> next;
	}
}

int main()
{

}