#include <iostream>
#include<graphics.h>
using namespace std;


void bezier(int x[4],int y[4])
{
int px,py,i;
double t;
for(t=0.0;t<=1.0;t+=0.0005)
{
px=(1-t)*(1-t)*(1-t)*x[0]+3*t*(1-t)*(1-t)*x[1]+3*t*t*(1-t)*x[2]+t*t*t*x[3];
py=(1-t)*(1-t)*(1-t)*y[0]+3*t*(1-t)*(1-t)*y[1]+3*t*t*(1-t)*y[2]+t*t*t*y[3];
putpixel(px,py,WHITE);
}
}


int main()
{
    int gd = DETECT, gm;
    initgraph (&gd, &gm, "..\\bgi");

    line(100, 70, 500, 70);

    int x1[] = {100, 130, 160, 120};
    int y1[] = {100, 70, 130, 150};
    bezier(x1, y1);
    int x2[] = {120, 160, 130, 100};
    int y2[] = {150, 170, 230, 200};
    bezier(x2, y2);
    line(120, 150, 160, 150);
    line(160, 70, 160, 230);

    int x3[] = {170, 200, 200, 170};
    int y3[] = {70, 120, 120, 150};
    bezier(x3, y3);
    int x4[] = {170, 200, 200, 240};
    int y4[] = {150, 170, 170, 150};
    bezier(x4, y4);
    line(240, 70, 240, 230);
    int x5[]={240,200,200,240};
    int y5[]={90,90,130,130};
    bezier(x5,y5);
    int x6[] = {240, 200, 200, 165};
    int y6[] = {70, 30, 30, 70};
    bezier(x6, y6);
    line(165, 70, 165, 230);

    line(340, 70, 340, 230);
    int x7[] = {340, 310, 310, 305};
    int y7[] = {180, 150, 150, 210};
    bezier(x7, y7);

    int x8[] = {300, 270, 270, 265};
    int y8[] = {180 ,150, 150, 230};
    bezier(x8, y8);

    line(340, 70, 300, 20);

    int x9[] = {370, 400, 400, 370};
    int y9[] = {70, 120, 120, 150};
    bezier(x9, y9);



  getch();


    return 0;
}
