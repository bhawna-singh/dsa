 #include <bits/stdc++.h>
using namespace std;

class Queue {
    stack<int> stack1, stack2;

    public:
    void enQueue(int x)
    {

        while (!stack1.empty()) {
            stack2.push(stack1.top());
            stack1.pop();
        }


        stack1.push(x);


        while (!stack2.empty()) {
            stack1.push(stack2.top());
            stack2.pop();
        }
    }


    int deQueue()
    {

        if (stack1.empty()) {
            cout << "Q is Empty";

        }


        int x = stack1.top();
        stack1.pop();
        return x;
    }
};


int main()
{
    Queue q;
    q.enQueue(7);
    q.enQueue(10);
    q.enQueue(2);

    cout << q.deQueue() << '\n';
    cout << q.deQueue() << '\n';
    cout << q.deQueue() << '\n';

    return 0;
}


   int pop2()
   {
       if (top2 < size)
       {
          int x = arr[top2];
          top2++;
          return x;
       }
       else
       {
           cout << "Stack UnderFlow";

       }
   }
};



int main()
{
    Stack s(5);
    s.push1(3);
    s.push2(12);
    s.push2(15);
    s.push1(1);
    s.push2(98);
    s.push2(4);
    cout << "Popped number from stack1 is " << s.pop1();
    
    cout << "\nPopped number from stack2 is " << s.pop2();
    return 0;
}
