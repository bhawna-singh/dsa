#include <iostream>
using namespace std;
class node{
 public:
    int data;
    node * next;
    node(int d){
        data = d;
        next = NULL;
    }
};
class Linkedlist{
 public:
    node * head;
    Linkedlist(){
        head = NULL;
    }
    node * search(int d){
        if(head == NULL){
            cout<<"empty"<<endl;
            return NULL;
        }
        node * ptr = head;
        while(ptr != NULL){
            if(ptr->data == d){
                return ptr;
            }
            if(ptr->data > d) break;
            ptr = ptr->next;
        }
        cout<<" not found "<<endl;
        return NULL;
        
    }
    void insert(int d){
        node * n = new node(d);
        if(head == NULL){
            head = n;
            head->next = NULL;
            return;
        }
        node * ptr = head;
        node * prev = NULL;
        while(ptr!= NULL && ptr->data < d){
            prev = ptr;
            ptr = ptr->next;
        }
        if(prev == NULL){
            n->next = head->next;
            head = n;
        }
        else{
            n->next = prev->next;
            prev->next = n;
        }
    }
    int del(int d){
        int item;
        if(head == NULL){
            cout<<"empty"<<endl;
            return -1;
        }
        node * prev = NULL;
        node * ptr = head;
        while(ptr != NULL){
            if(ptr->data == d){
                if(prev == NULL){
                   item = head->data;
                   head = head->next;
                   return item;
                }
                else{
                    item = ptr->data;
                    prev->next = ptr->next;
                    return item;
                }
            }
            if(ptr->data > d) {
                cout<<"not found"<<endl;
                return -1;
            }
            prev = ptr;
            ptr = ptr->next;
        }
        
    }
    void printll(){
        if(head == NULL) return;
        node * ptr = head;
        //node * prev = NULL;
        while(ptr->next != NULL){
            cout<<ptr->data<<" -> ";
            //prev = ptr;
            ptr = ptr->next;
        }
        cout<<ptr->data<<endl;
    }
};


int main() {
	Linkedlist l;
	l.insert(1);
	l.insert(2);
	l.insert(3);
	l.del(3);
	l.printll();
	return 0;
}
