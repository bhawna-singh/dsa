#include<iostream>
#include<stack>

using namespace std;

int exp_eval(string);
int operation(int,int,char);
bool isoperator(char);
bool predence(char,char);

int main()
{
    string exp;
    int ans;
    cout<<"Enter Infix Arithmetic Expression: ";
    cin >>exp;
    ans= exp_eval(exp);
    cout<<"The value of the Infix Arithmetic Expression is: "<<ans<<endl;
    return 0;
}

int exp_eval(string exp)
{
    stack<int> opr; //stack1
    stack<char> op; //stack2
    for(int i=0; i<exp.length(); i++)
    {
        if(isdigit(exp[i]))
        {
            int num=0;
            while(isdigit(exp[i]))
            {
                num*=10;
                num+=exp[i]-'0';
                i++;
            }
            opr.push(num);
            i--;
            }
        else if(exp[i]=='(')
            op.push(exp[i]);
        else if(exp[i]==')')
        {
            while(op.top()!='(')
            {
                char c=op.top();
                op.pop();
                int a=opr.top();
                opr.pop();
                int b= opr.top();
                opr.pop();
                int result= operation(a,b,c);
                opr.push(result);
            }
            op.pop();
        }
        else if(isoperator(exp[i]))
        {
            while(!op.empty() && predence(op.top(),exp[i]))
            {
                char c=op.top();
                op.pop();
                int a=opr.top();
                opr.pop();
                int b= opr.top();
                opr.pop();
                int result= operation(a,b,c);
                opr.push(result);
            }
            op.push(exp[i]);
        }

    }
    while(!op.empty())
    {
        char c=op.top();
        op.pop();
        int a=opr.top();
        opr.pop();
        int b= opr.top();
        opr.pop();
        int result= operation(a,b,c);
        opr.push(result);

    }
    return opr.top();
}

int operation(int a, int b, char c)
{
    if(c=='+')
        return b+a;
    else if(c=='-')
        return b-a;
    else if(c=='*')
        return b*a;
    else if(c=='/')
        return b/a;
    else if(c=='^')
    {
        int value=1;
        for(int i=0;i<a;i++)
            value*=b;
        return value;
    }
    return 0;

}

bool isoperator(char c)
{
    if(c=='+'||c=='-'||c=='*'||c=='/'||c=='^')
        return 1;
    else return 0;
}

bool predence(char a, char b)
{
    if( a=='^')
        return 1;
    else if(a=='/'||a=='*'&& b!='^')
        return 1;
    else if(a=='+'||a=='-'&& b=='+'||b=='-')
        return 1;
    else
        return 0;
}// (4+8)*(6-5)/((3-2)*(2+2))
