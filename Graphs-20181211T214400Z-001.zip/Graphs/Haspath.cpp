#include<iostream>
using namespace std;

void DFS(int **edges, int sv, bool* visited, int v)
{
    visited[sv] = true;
    for(int i = 0; i < v; i++)
    {
        if(visited[i] == true || i == sv)
         continue;

         if(edges[sv][i] == 1)
           DFS(edges, i, visited, v);
           
    }
}
bool Haspath(int **edges, int v1, int v2, bool * visited, int v)
{
    DFS(edges, v1, visited, v);
    if(visited[v2] == true)
     return true;

     else return false;
    
}


int main()
{
    int v,e;
    cin >> v >> e;

    int** edges = new int*[v];

    for(int i = 0; i < v; i++)
    {
        edges[i] = new int[v];

        for(int j = 0; j < v; j++)
         edges[i][j] = 0;
    }

    for(int i = 0; i < e; i++)
    {
        int f,s;
        cin >> f >> s;
        edges[f][s] = 1;
        edges[s][f] = 1;
    }

        
    bool * visited = new bool[v];
    for (int i = 0; i < v; i++)
    {
        visited[i] = false;
    }

    int v1, v2;
    cin >> v1 >> v2;
    if (Haspath(edges, v1, v2, visited, v))
    {
        cout << "true";
    }
    else cout << "false";
   
     

}