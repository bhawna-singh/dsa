#include<vector>
#include<iostream>
#include<queue>
#include<unordered_map>
using namespace std;


void DFS(int **edges, int sv, bool* visited, int v)
{
    visited[sv] = true;
    for(int i = 0; i < v; i++)
    {
        if(visited[i] == true || i == sv)
         continue;

         if(edges[sv][i] == 1)
           DFS(edges, i, visited, v);
           
    }
}
bool Haspath(int **edges, int v1, int v2, bool * visited, int v)
{
    DFS(edges, v1, visited, v);
    if(visited[v2] == true)
     return true;

     else return false;
    
}

vector<int>* GetPathDFS(int ** edges, int v, int v1, int v2, bool* visited)
{
   vector<int>* ans = new vector<int>();

   if(v1 == v2)
    {
        ans -> push_back(v1);
        return ans;
    }

    for(int i = 0; i < v; i++)
    {
        if(visited[i] == true || i == v1)
         continue;

         if(edges[v1][i] == true)
          {
              vector<int>* smallans = GetPathDFS(edges, v, i, v2, visited);
              if(smallans != NULL)
              {
                  smallans -> push_back(v1);
                  return smallans;
              }
              else return NULL;
          }
    }

    return NULL;
    
}

vector<int>* GetPathBFS(int ** edges, int v, int v1, int v2, bool* visited)
{
   queue<int> pendingVertices;
   visited[v1] = true;
   pendingVertices.push(v1);

   unordered_map<int, int> m;

   while(pendingVertices.front() != v2)
   {
       for(int i = 0; i < v; i++)
       {
           if(i == pendingVertices.front() || visited[i] == true)
            continue;

           else 
           {
               pendingVertices.push(i);
               m[pendingVertices.front()] = i;
           }
           if(i == v2)
            break;
       }
       pendingVertices.pop();
   }
   vector<int> *ans = new vector<int>();

  if(m.count(v2) > 0)
  {
        ans -> push_back(v2);
        int k = v2;
        while(k != v1)
        {
            ans -> push_back(m[k]);
            k = m[k];
        }

        ans -> push_back(v1);
        return ans;
  }


  else return NULL;

}


int main()
{
    int v,e;
    cin >> v >> e;

    int** edges = new int*[v];

    for(int i = 0; i < v; i++)
    {
        edges[i] = new int[v];

        for(int j = 0; j < v; j++)
         edges[i][j] = 0;
    }

    for(int i = 0; i < e; i++)
    {
        int f,s;
        cin >> f >> s;
        edges[f][s] = 1;
        edges[s][f] = 1;
    }

        
    bool * visited = new bool[v];
    for (int i = 0; i < v; i++)
    {
        visited[i] = false;
    }

    int v1, v2;
    cin >> v1 >> v2;
    if (Haspath(edges, v1, v2, visited, v))
    {
        cout << "true";
    }
    else cout << "false";
   
     

}